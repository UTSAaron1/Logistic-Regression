import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

home_dir = os.path.expanduser("~")

file_path = os.path.join(home_dir, "Desktop", "Phishing_Email.csv")

df = pd.read_csv(file_path)

df['Email Text'].fillna('', inplace=True)

X = df['Email Text']
y = df['Email Type']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

vectorizer = TfidfVectorizer()
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

model = LogisticRegression()
model.fit(X_train_vec, y_train)

y_pred = model.predict(X_test_vec)

accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

print("\nClassification Report:")
print(classification_report(y_test, y_pred))

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))

input_data_not_fraudulent = [
    "Hello, Thank you for your recent purchase! We appreciate your business.",
    "Your subscription has been successfully renewed. Enjoy access to premium content.",
    "Reminder: Your appointment is scheduled for tomorrow at 2:00 PM.",
]

input_vec_not_fraudulent = vectorizer.transform(input_data_not_fraudulent)

predictions_not_fraudulent = model.predict(input_vec_not_fraudulent)

print("\nPredictions for Input Data (Not Fraudulent):")
for text, prediction in zip(input_data_not_fraudulent, predictions_not_fraudulent):
    print(f"Input: {text}")
    print(f"Predicted Type: {prediction}\n")